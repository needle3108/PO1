#pragma once

#include"Figures.h"

void draw(Drawable *d){
    d->draw();
}