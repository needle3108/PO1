#pragma once

#include<vector>
#include<algorithm>

class Student;
class School;

using namespace std;

class Table{
    public:
        bool cmp(Student a, Student b){
                return a._points > b._points;
        }

        Table(vector<Student>);
        Table(School*);

        Table & operator +=(Student v){
            this->_students.push_back(v);
            return *this;
        }

        Table & operator +=(School *v){
            this->_schools.push_back(v);
            return *this;
        }

        void sortpoints(){
            sort(_students.begin(), _students.end(), cmp);
        }

    private:
        vector<Student> _students;
        vector<School*> _schools;
};